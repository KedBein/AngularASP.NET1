"use strict";
var DeferObservable_1 = require('./DeferObservable');
exports.defer = DeferObservable_1.DeferObservable.create;
//# sourceMappingURL=defer.js.map