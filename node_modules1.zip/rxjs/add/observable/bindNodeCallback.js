"use strict";
var Observable_1 = require('../../Observable');
var bindNodeCallback_1 = require('../../observable/bindNodeCallback');
Observable_1.Observable.bindNodeCallback = bindNodeCallback_1.bindNodeCallback;
//# sourceMappingURL=bindNodeCallback.js.map