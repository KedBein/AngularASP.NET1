"use strict";
var Observable_1 = require('../../Observable');
var merge_1 = require('../../observable/merge');
Observable_1.Observable.merge = merge_1.merge;
//# sourceMappingURL=merge.js.map