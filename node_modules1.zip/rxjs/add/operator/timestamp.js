"use strict";
var Observable_1 = require('../../Observable');
var timestamp_1 = require('../../operator/timestamp');
Observable_1.Observable.prototype.timestamp = timestamp_1.timestamp;
//# sourceMappingURL=timestamp.js.map