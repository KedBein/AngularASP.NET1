"use strict";
var Observable_1 = require('../../Observable');
var exhaustMap_1 = require('../../operator/exhaustMap');
Observable_1.Observable.prototype.exhaustMap = exhaustMap_1.exhaustMap;
//# sourceMappingURL=exhaustMap.js.map