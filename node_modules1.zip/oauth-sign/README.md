oauth-sign
==========

OAuth 1 signing. Formerly a vendor lib in mikeal/request, now a standalone module. 
