export declare class TemplateDrivenErrors {
    static modelParentException(): void;
    static formGroupNameException(): void;
    static missingNameException(): void;
    static modelGroupParentException(): void;
}
